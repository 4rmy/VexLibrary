#pragma once

namespace Lib {

// constants
static constexpr int DELAY = 10;

void init();
void opcontrol();
void auton();

} // namespace Lib

// misc
#include "misc/wheels.hpp" // IWYU: keep

// utilities
#include "utils/chassis.hpp" // IWYU: keep
#include "utils/pose.hpp" // IWYU: keep
#include "utils/tracking_wheel.hpp" // IWYU: keep

// sub systems
#include "subs/odom.hpp" // IWYU: keep
#include "subs/pid.hpp"  // IWYU: keep

// library callbacks to sync with VEX
inline void Lib::init() {}
inline void Lib::opcontrol() {}
inline void Lib::auton() {}
